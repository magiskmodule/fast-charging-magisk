# Changelog

## v1.3

- Migrated to latest MMT-Reborn Template
- Written code from scratch
- Added 32-bit support
- Added three modes i.e Fast, Faster & Fastest
- Increased support for newer devices
- Misc. changes & bug fixes